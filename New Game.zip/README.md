# SUPER ADVENTURE

A self-contained Godot 4 platformer. Open `project.godot` and press F5.

## Controls
- Move: A / D or Left / Right
- Jump: Space, W, or Up
- Pause: P or Escape
- Stomp enemies from above; side contact costs a life.
- Each coin is worth 10 points. Reach the finish flag to continue.

## Scene tree
- `Main.tscn` is the game entry point.
- `Player.tscn` is a `CharacterBody2D` with a body `CollisionShape2D`, visual polygon nodes and `Camera2D`.
- `Enemy.tscn` is a `CharacterBody2D` with body collision, `StompArea` and `ContactArea`, each with its own `CollisionShape2D`.
- `Coin.tscn` and `FinishFlag.tscn` are `Area2D` scenes with collision shapes and signals.
- `Platform.tscn` is a `StaticBody2D` with an editable `CollisionShape2D` and polygon visuals.
- `KillZone.tscn` is an `Area2D` with a configurable `CollisionShape2D` that detects falls.
- `HUD.tscn` handles the menu, counters, pause and ending panels.
- `GameLevel.tscn` and the main controller assemble three level layouts from those reusable scenes.

No external art or audio assets are required; the project draws its characters and sounds locally.
