extends Area2D
signal player_fell(player: AdventurePlayer)
@onready var collision_shape: CollisionShape2D = $CollisionShape2D
func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	body_entered.connect(_on_body_entered)
func configure(width: float) -> void:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(width + 400.0, 100.0)
	collision_shape.shape = shape
func _on_body_entered(body: Node2D) -> void:
	if body is AdventurePlayer: player_fell.emit(body)
