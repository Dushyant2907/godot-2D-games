extends CharacterBody2D
class_name AdventurePlayer
signal jumped
const SPEED := 250.0
const ACCEL := 1500.0
const FRICTION := 1900.0
const JUMP_VELOCITY := -510.0
var gravity := 1250.0
var facing := 1.0
var anim_time := 0.0
var invulnerable := 0.0
@onready var visual: Node2D = $Visual
@onready var left_leg: Polygon2D = $Visual/LeftLeg
@onready var right_leg: Polygon2D = $Visual/RightLeg
func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 8.0
func _physics_process(delta: float) -> void:
	anim_time += delta
	invulnerable = maxf(invulnerable - delta, 0.0)
	if not is_on_floor(): velocity.y += gravity * delta
	var direction := Input.get_axis("move_left", "move_right")
	if direction != 0.0:
		facing = signf(direction)
		velocity.x = move_toward(velocity.x, direction * SPEED, ACCEL * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, FRICTION * delta)
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		jumped.emit()
	move_and_slide()
	var running := absf(velocity.x) > 18.0 and is_on_floor()
	visual.scale.x = facing
	visual.position.y = sin(anim_time * 16.0) * 2.0 if running else (sin(anim_time * 3.0) if is_on_floor() else 0.0)
	visual.rotation = -0.08 if not is_on_floor() and velocity.y < 0.0 else 0.0
	left_leg.rotation = sin(anim_time * 16.0) * 0.45 if running else 0.0
	right_leg.rotation = -sin(anim_time * 16.0) * 0.45 if running else 0.0
	visual.visible = invulnerable <= 0.0 or int(anim_time * 14.0) % 2 != 0
