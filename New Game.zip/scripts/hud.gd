extends CanvasLayer
class_name AdventureHUD
signal start_game
signal pause_requested
signal resume_game
signal restart_game
signal go_menu
signal next_level
signal clicked
var stats_label: Label
var level_label: Label
var overlay: ColorRect
var panel: VBoxContainer
var current_panel := ""
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	var bar := PanelContainer.new()
	bar.position = Vector2(18, 16)
	bar.add_theme_stylebox_override("panel", _style(Color("173d65"), 14))
	root.add_child(bar)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 18)
	bar.add_child(row)
	stats_label = Label.new()
	stats_label.text = "COINS 0    SCORE 0    LIVES 3"
	stats_label.add_theme_font_size_override("font_size", 18)
	stats_label.add_theme_color_override("font_color", Color("fff4d7"))
	row.add_child(stats_label)
	level_label = Label.new()
	level_label.add_theme_font_size_override("font_size", 16)
	level_label.add_theme_color_override("font_color", Color("d3edff"))
	row.add_child(level_label)
	var pause_button := _button("PAUSE", false)
	pause_button.pressed.connect(func(): clicked.emit(); pause_requested.emit())
	row.add_child(pause_button)
	var help := Label.new()
	help.text = "MOVE: A/D or arrows     JUMP: Space / W / Up"
	help.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	help.position = Vector2(-430, 20)
	help.size = Vector2(410, 28)
	help.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	help.add_theme_font_size_override("font_size", 14)
	help.add_theme_color_override("font_color", Color("173d65"))
	root.add_child(help)
	overlay = ColorRect.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.color = Color(0.05, 0.12, 0.22, 0.72)
	root.add_child(overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(440, 0)
	card.add_theme_stylebox_override("panel", _style(Color("fff5dc"), 24))
	center.add_child(card)
	panel = VBoxContainer.new()
	panel.add_theme_constant_override("separation", 14)
	panel.add_theme_constant_override("margin_left", 30)
	panel.add_theme_constant_override("margin_right", 30)
	panel.add_theme_constant_override("margin_top", 26)
	panel.add_theme_constant_override("margin_bottom", 26)
	card.add_child(panel)
	show_menu()
func update_stats(coins: int, score: int, lives: int, level_num: int) -> void:
	stats_label.text = "COINS %d    SCORE %d    LIVES %d" % [coins, score, lives]
	var names := ["Easy Meadow", "Bouncy Hills", "Skyline Sprint"]
	level_label.text = "  •  LEVEL %d: %s" % [level_num, names[clampi(level_num - 1, 0, 2)]]
func show_menu() -> void:
	_show_panel("SUPER ADVENTURE", "A bright little platforming quest!\n\nCollect coins, bounce on baddies,\nand reach the flag at each level's end.", [["PLAY", "start"], ["CONTROLS", "help"]])
func show_pause() -> void:
	_show_panel("PAUSED", "Take a breather, adventurer.", [["RESUME", "resume"], ["RESTART LEVEL", "restart"], ["MAIN MENU", "menu"]])
func show_game_over(score: int, coins: int) -> void:
	_show_panel("GAME OVER", "Your adventure ends here.\nFinal score: %d     Coins: %d" % [score, coins], [["TRY AGAIN", "restart"], ["MAIN MENU", "menu"]])
func show_complete(score: int, coins: int, level_num: int) -> void:
	var final_level := level_num >= 3
	var title := "ADVENTURE COMPLETE!" if final_level else "LEVEL %d COMPLETE!" % level_num
	var message := "You conquered every course!\nFinal score: %d     Coins: %d" % [score, coins] if final_level else "Great jumping!\nScore: %d     Coins: %d" % [score, coins]
	var actions := [["PLAY AGAIN", "restart"], ["MAIN MENU", "menu"]] if final_level else [["NEXT LEVEL", "next"], ["MAIN MENU", "menu"]]
	_show_panel(title, message, actions)
func hide_overlay() -> void:
	overlay.visible = false
	current_panel = ""
func _show_panel(title: String, message: String, actions: Array) -> void:
	current_panel = title
	overlay.visible = true
	for child in panel.get_children(): child.queue_free()
	var heading := Label.new()
	heading.text = title
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size", 32 if title.length() < 18 else 26)
	heading.add_theme_color_override("font_color", Color("d75139"))
	panel.add_child(heading)
	var body := Label.new()
	body.text = message
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.add_theme_font_size_override("font_size", 18)
	body.add_theme_color_override("font_color", Color("38536b"))
	panel.add_child(body)
	for action in actions:
		var button := _button(action[0], true)
		button.pressed.connect(_on_action.bind(action[1]))
		panel.add_child(button)
func _on_action(action: String) -> void:
	clicked.emit()
	match action:
		"start": start_game.emit()
		"resume": hide_overlay(); resume_game.emit()
		"restart": restart_game.emit()
		"menu": go_menu.emit()
		"next": next_level.emit()
		"help": _show_panel("HOW TO PLAY", "Move with A/D or arrow keys.\nJump with Space, W or Up.\nLand on enemies to squash them!\nEach coin gives 10 points.\nWatch your step near gaps!", [["GOT IT", "back"]])
		"back": show_menu()
func _button(caption: String, wide: bool) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(230 if wide else 100, 48 if wide else 36)
	button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER if wide else Control.SIZE_SHRINK_END
	button.add_theme_font_size_override("font_size", 18 if wide else 14)
	button.add_theme_color_override("font_color", Color("fff9eb"))
	button.add_theme_stylebox_override("normal", _style(Color("347fc1"), 12))
	button.add_theme_stylebox_override("hover", _style(Color("2467a5"), 12))
	button.add_theme_stylebox_override("pressed", _style(Color("d75139"), 12))
	return button
func _style(color: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_left = radius
	style.corner_radius_bottom_right = radius
	style.content_margin_left = 15
	style.content_margin_right = 15
	style.content_margin_top = 9
	style.content_margin_bottom = 9
	return style
