extends Node2D
const PLAYER_SCENE := preload("res://scenes/Player.tscn")
const ENEMY_SCENE := preload("res://scenes/Enemy.tscn")
const COIN_SCENE := preload("res://scenes/Coin.tscn")
const PLATFORM_SCENE := preload("res://scenes/Platform.tscn")
const KILL_ZONE_SCENE := preload("res://scenes/KillZone.tscn")
const FLAG_SCENE := preload("res://scenes/FinishFlag.tscn")
const HUD_SCENE := preload("res://scenes/HUD.tscn")
var hud: AdventureHUD
var player: AdventurePlayer
var platform_root: Node2D
var coin_root: Node2D
var enemy_root: Node2D
var platforms: Array = []
var coin_nodes: Array[AdventureCoin] = []
var enemy_nodes: Array[AdventureEnemy] = []
var level_index := 1
var score := 0
var coins := 0
var lives := 3
var level_width := 3600.0
var spawn := Vector2(100, 583)
var in_game := false
var game_state := "menu"
var audio_music: AudioStreamPlayer
var audio_fx: AudioStreamPlayer
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_input()
	_setup_audio()
	hud = HUD_SCENE.instantiate()
	add_child(hud)
	hud.start_game.connect(start_run)
	hud.pause_requested.connect(_pause_game)
	hud.resume_game.connect(_resume_game)
	hud.restart_game.connect(start_run)
	hud.go_menu.connect(show_menu)
	hud.next_level.connect(_next_level)
	hud.clicked.connect(func(): _play_fx(740.0, 0.07))
	show_menu()
func _ensure_input() -> void:
	_add_key("move_left", KEY_A)
	_add_key("move_left", KEY_LEFT)
	_add_key("move_right", KEY_D)
	_add_key("move_right", KEY_RIGHT)
	_add_key("jump", KEY_SPACE)
	_add_key("jump", KEY_W)
	_add_key("jump", KEY_UP)
	_add_key("pause", KEY_P)
	_add_key("pause", KEY_ESCAPE)
func _add_key(action: String, keycode: Key) -> void:
	if not InputMap.has_action(action): InputMap.add_action(action)
	for event in InputMap.action_get_events(action):
		if event is InputEventKey and event.keycode == keycode: return
	var key := InputEventKey.new()
	key.keycode = keycode
	InputMap.action_add_event(action, key)
func _process(_delta: float) -> void:
	if game_state == "playing" and player != null and Input.is_action_just_pressed("pause"):
		_pause_game()
func start_run() -> void:
	get_tree().paused = false
	level_index = 1
	score = 0
	coins = 0
	lives = 3
	_start_level()
func _start_level() -> void:
	_clear_level()
	in_game = true
	game_state = "playing"
	var data := _level_data(level_index)
	level_width = data.width
	platforms = data.platforms
	spawn = Vector2(100, float(data.ground_y) - 67.0)
	_build_level_nodes(data)
	player = PLAYER_SCENE.instantiate()
	player.position = spawn
	player.jumped.connect(func(): _play_fx(520.0, 0.1))
	add_child(player)
	var camera: Camera2D = player.get_node("Camera2D")
	camera.limit_right = int(level_width)
	camera.make_current()
	_refresh_hud()
	hud.hide_overlay()
	get_tree().paused = false
	queue_redraw()
func _level_data(which: int) -> Dictionary:
	if which == 1:
		return {"width":3600.0,"ground_y":650,"platforms":[[0,650,760,100],[930,650,660,100],[1740,650,760,100],[2650,650,950,100],[400,500,180,26],[1040,525,170,26],[1370,445,170,26],[1930,500,190,26],[2260,420,190,26],[2880,525,190,26],[3190,445,180,26]],"coins":[[300,570],[390,455],[455,455],[520,455],[800,540],[1070,480],[1140,480],[1430,400],[1510,400],[1610,570],[1810,570],[1990,455],[2060,455],[2320,375],[2400,375],[2550,565],[2780,570],[2940,480],[3010,480],[3260,400],[3330,400],[3440,570]],"enemies":[[570,610,700],[1270,610,1510],[2160,610,2440],[3010,610,3500]]}
	if which == 2:
		return {"width":4300.0,"ground_y":650,"platforms":[[0,650,620,100],[790,650,500,100],[1480,650,470,100],[2130,650,520,100],[2850,650,520,100],[3570,650,730,100],[300,510,160,24],[620,430,170,24],[1020,520,170,24],[1320,440,170,24],[1670,500,175,24],[1980,410,170,24],[2380,510,170,24],[2670,430,170,24],[3020,500,170,24],[3370,420,170,24],[3780,500,180,24],[4020,400,180,24]],"coins":[[260,560],[340,465],[410,465],[665,385],[735,385],[890,570],[1070,475],[1140,475],[1370,395],[1740,455],[1810,455],[2020,365],[2090,365],[2260,570],[2440,465],[2510,465],[2730,385],[2800,385],[3110,455],[3180,455],[3420,375],[3490,375],[3710,570],[3840,455],[3910,455],[4070,355],[4140,355]],"enemies":[[470,610,570],[930,610,1230],[1590,610,1880],[2220,610,2570],[2960,610,3300],[3650,610,4210]]}
	return {"width":5000.0,"ground_y":650,"platforms":[[0,650,520,100],[700,650,430,100],[1310,650,420,100],[1910,650,440,100],[2530,650,420,100],[3130,650,430,100],[3740,650,430,100],[4360,650,640,100],[200,500,150,24],[490,415,155,24],[780,490,150,24],[1030,390,150,24],[1400,500,150,24],[1610,400,150,24],[2010,480,150,24],[2250,370,155,24],[2620,490,150,24],[2860,390,150,24],[3220,480,150,24],[3460,370,150,24],[3840,480,150,24],[4070,375,150,24],[4450,490,150,24],[4690,380,150,24]],"coins":[[180,570],[240,455],[305,455],[540,370],[605,370],[850,440],[910,440],[1080,345],[1140,345],[790,570],[1460,450],[1520,450],[1670,355],[1730,355],[2000,430],[2060,430],[2310,330],[2370,330],[2670,440],[2730,440],[2920,350],[2980,350],[3260,430],[3320,430],[3500,330],[3560,330],[3860,430],[3920,430],[4140,335],[4200,335],[4480,440],[4540,440],[4730,340],[4790,340]],"enemies":[[380,610,485],[780,610,1090],[1380,610,1690],[1970,610,2310],[2600,610,2840],[3190,610,3520],[3790,610,4120],[4430,610,4910]]}
func _build_level_nodes(data: Dictionary) -> void:
	platform_root = Node2D.new()
	platform_root.name = "Platforms"
	platform_root.z_index = 1
	add_child(platform_root)
	coin_root = Node2D.new()
	coin_root.name = "Coins"
	coin_root.z_index = 3
	add_child(coin_root)
	enemy_root = Node2D.new()
	enemy_root.name = "Enemies"
	enemy_root.z_index = 4
	add_child(enemy_root)
	for p in platforms:
		var platform: StaticBody2D = PLATFORM_SCENE.instantiate()
		var ground := float(p[3]) > 30.0
		var x := float(p[0]) + float(p[2]) / 2.0 if ground else float(p[0])
		platform.position = Vector2(x, float(p[1]))
		platform_root.add_child(platform)
		platform.configure(float(p[2]), float(p[3]), ground)
	var kill_zone: Area2D = KILL_ZONE_SCENE.instantiate()
	kill_zone.position = Vector2(level_width / 2.0, 900)
	add_child(kill_zone)
	kill_zone.configure(level_width)
	kill_zone.player_fell.connect(_on_player_fell)
	var flag: Area2D = FLAG_SCENE.instantiate()
	flag.position = Vector2(level_width - 110.0, 550.0)
	add_child(flag)
	flag.player_reached_flag.connect(func(_p): _complete_level())
	_create_coins(data.coins)
	_create_enemies(data.enemies)
func _create_coins(points: Array) -> void:
	coin_nodes.clear()
	for point in points:
		var coin: AdventureCoin = COIN_SCENE.instantiate()
		coin.position = Vector2(float(point[0]), float(point[1]))
		coin.collected.connect(_on_coin_collected)
		coin_root.add_child(coin)
		coin_nodes.append(coin)
func _create_enemies(rows: Array) -> void:
	enemy_nodes.clear()
	for row in rows:
		var enemy: AdventureEnemy = ENEMY_SCENE.instantiate()
		enemy.position = Vector2(float(row[0]), float(row[1]) - 27.0)
		enemy.setup(float(row[0]) - 120.0, float(row[2]), 60.0 + level_index * 8.0)
		enemy.stomped.connect(_on_enemy_stomped)
		enemy.touched.connect(_on_enemy_touched)
		enemy_root.add_child(enemy)
		enemy_nodes.append(enemy)
func _on_coin_collected(coin: AdventureCoin) -> void:
	coin.collect()
	coins += 1
	score += 10
	_play_fx(990.0, 0.12)
	_refresh_hud()
func _on_enemy_stomped(enemy: AdventureEnemy, stomp_player: AdventurePlayer) -> void:
	stomp_player.velocity.y = -340.0
	enemy_nodes.erase(enemy)
	enemy.queue_free()
	score += 100
	_play_fx(280.0, 0.18)
	_refresh_hud()
func _on_enemy_touched(_enemy: AdventureEnemy, hit_player: AdventurePlayer) -> void:
	if hit_player.velocity.y > 40.0 and hit_player.global_position.y < _enemy.global_position.y - 6.0:
		_on_enemy_stomped(_enemy, hit_player)
	else:
		_damage_player()
func _on_player_fell(_player: AdventurePlayer) -> void:
	_damage_player(true)
func _damage_player(fell: bool = false) -> void:
	if player == null or player.invulnerable > 0.0: return
	lives -= 1
	_play_fx(170.0, 0.22)
	if lives <= 0 or fell:
		game_state = "game_over"
		in_game = false
		get_tree().paused = true
		hud.show_game_over(score, coins)
		_play_fx(110.0, 0.5)
	else:
		player.global_position = spawn
		player.velocity = Vector2.ZERO
		player.invulnerable = 1.5
	_refresh_hud()
func _complete_level() -> void:
	if game_state != "playing": return
	game_state = "complete"
	in_game = false
	get_tree().paused = true
	_play_fx(880.0, 0.4)
	hud.show_complete(score, coins, level_index)
func _next_level() -> void:
	level_index += 1
	_start_level()
func _pause_game() -> void:
	if game_state != "playing": return
	game_state = "paused"
	get_tree().paused = true
	hud.show_pause()
func _resume_game() -> void:
	game_state = "playing"
	get_tree().paused = false
func show_menu() -> void:
	get_tree().paused = false
	in_game = false
	game_state = "menu"
	_clear_level()
	hud.show_menu()
func _clear_level() -> void:
	for child in get_children():
		if child != hud and child != audio_music and child != audio_fx: child.free()
	player = null
	platform_root = null
	coin_root = null
	enemy_root = null
	coin_nodes.clear()
	enemy_nodes.clear()
	platforms.clear()
	queue_redraw()
func _refresh_hud() -> void:
	if hud != null: hud.update_stats(coins, score, lives, level_index)
func _draw() -> void:
	var right := level_width if in_game else 1600.0
	draw_rect(Rect2(-200,-100,right+400,1100), Color("87d8ff"), true)
	for i in range(int(right / 360.0) + 2):
		var x := float(i) * 360.0 - 100.0
		draw_circle(Vector2(x,620),190,Color("7ecb9a"))
		draw_circle(Vector2(x+190,626),145,Color("99d7a3"))
	for i in range(int(right / 520.0) + 2):
		var x := float(i) * 520.0 + 100.0
		var y := 100.0 + float((i * 73) % 130)
		draw_circle(Vector2(x,y),29,Color("f7fdff"))
		draw_circle(Vector2(x+31,y-10),39,Color("f7fdff"))
		draw_circle(Vector2(x+68,y),27,Color("f7fdff"))
		draw_rect(Rect2(x-4,y-1,76,27),Color("f7fdff"),true)
	for x in range(270, int(right), 780):
		draw_rect(Rect2(float(x),562,70,88),Color("249e57"),true)
		draw_rect(Rect2(float(x-9),550,88,20),Color("32c56d"),true)
		draw_rect(Rect2(float(x+14),582,12,18),Color("72e391"),true)
	for x in range(600, int(right), 1080):
		draw_rect(Rect2(float(x),548,18,102),Color("93613f"),true)
		draw_circle(Vector2(x+9,523),44,Color("3ba969"))
		draw_circle(Vector2(x-15,541),29,Color("56c878"))
		draw_circle(Vector2(x+34,540),29,Color("56c878"))
func _setup_audio() -> void:
	audio_music = AudioStreamPlayer.new()
	audio_music.process_mode = Node.PROCESS_MODE_ALWAYS
	audio_music.volume_db = -18
	add_child(audio_music)
	audio_music.stream = _make_music()
	audio_music.play()
	audio_fx = AudioStreamPlayer.new()
	audio_fx.process_mode = Node.PROCESS_MODE_ALWAYS
	audio_fx.volume_db = -6
	add_child(audio_fx)
func _make_tone(frequency: float, duration: float, volume: float = 0.22) -> AudioStreamWAV:
	const RATE := 22050
	var frames := int(RATE * duration)
	var samples := PackedByteArray()
	samples.resize(frames * 2)
	for i in range(frames):
		var fade := minf(1.0, float(frames - i) / (RATE * 0.025))
		samples.encode_s16(i * 2, int(sin(TAU * frequency * float(i) / RATE) * volume * fade * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.data = samples
	return wav
func _make_music() -> AudioStreamWAV:
	const RATE := 22050
	var frames := RATE * 6
	var samples := PackedByteArray()
	samples.resize(frames * 2)
	var notes := [392.0,523.25,587.33,523.25,440.0,392.0,329.63,392.0,440.0,523.25,659.25,523.25]
	for i in range(frames):
		var t := float(i) / RATE
		var note: float = notes[int(t / 0.5) % notes.size()]
		var melody := sin(TAU * note * t) * 0.55 + sin(TAU * note * 2.0 * t) * 0.15
		var bass := sin(TAU * (130.81 if int(t) % 2 == 0 else 164.81) * t) * 0.22
		samples.encode_s16(i * 2, int((melody * 0.14 + bass) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.data = samples
	wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
	wav.loop_end = frames
	return wav
func _play_fx(frequency: float, duration: float) -> void:
	audio_fx.stream = _make_tone(frequency, duration)
	audio_fx.play()
