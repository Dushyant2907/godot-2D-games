extends Area2D
class_name AdventureCoin
signal collected(coin: AdventureCoin)
var anim_time := 0.0
var already_collected := false
@onready var visual: Node2D = $Visual
func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
	anim_time += delta
	visual.scale.x = 0.48 + absf(sin(anim_time * 5.0)) * 0.52
	visual.position.y = sin(anim_time * 3.0) * 3.0
func _on_body_entered(body: Node2D) -> void:
	if body is AdventurePlayer and not already_collected:
		already_collected = true
		collected.emit(self)
func collect() -> void:
	hide()
	set_deferred("monitoring", false)
