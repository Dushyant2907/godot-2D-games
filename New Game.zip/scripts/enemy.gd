extends CharacterBody2D
class_name AdventureEnemy
signal stomped(enemy: AdventureEnemy, player: AdventurePlayer)
signal touched(enemy: AdventureEnemy, player: AdventurePlayer)
var walk_left := 0.0
var walk_right := 0.0
var direction := -1.0
var speed := 62.0
var anim_time := 0.0
var defeated := false
@onready var visual: Node2D = $Visual
@onready var left_leg: Polygon2D = $Visual/LeftLeg
@onready var right_leg: Polygon2D = $Visual/RightLeg
func setup(left_edge: float, right_edge: float, pace: float) -> void:
	walk_left = left_edge
	walk_right = right_edge
	speed = pace
func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	$StompArea.body_entered.connect(_on_player_entered)
	$ContactArea.body_entered.connect(_on_player_entered)
func _physics_process(delta: float) -> void:
	anim_time += delta
	velocity.y += 1250.0 * delta
	if global_position.x < walk_left: direction = 1.0
	elif global_position.x > walk_right: direction = -1.0
	velocity.x = direction * speed
	move_and_slide()
	visual.scale.x = direction
	var step := sin(anim_time * 13.0) * 0.38
	left_leg.rotation = step
	right_leg.rotation = -step
	visual.position.y = absf(step) * 2.0
func _on_player_entered(body: Node2D) -> void:
	if not body is AdventurePlayer or defeated: return
	if body.velocity.y > 40.0 and body.global_position.y < global_position.y - 6.0:
		defeated = true
		stomped.emit(self, body)
	else:
		touched.emit(self, body)
