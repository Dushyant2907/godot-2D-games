extends Area2D
signal player_reached_flag(player: AdventurePlayer)
func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	body_entered.connect(_on_body_entered)
func _on_body_entered(body: Node2D) -> void:
	if body is AdventurePlayer: player_reached_flag.emit(body)
