extends StaticBody2D
@onready var collision_shape: CollisionShape2D = $CollisionShape2D
@onready var body_visual: Polygon2D = $Visual/Body
@onready var top_visual: Polygon2D = $Visual/Top
func _ready() -> void:
	collision_layer = 1
	collision_mask = 0
func configure(width: float, height: float, is_ground: bool) -> void:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(width, height)
	collision_shape.shape = shape
	var left := -width * 0.5
	var top := -height * 0.5
	body_visual.polygon = PackedVector2Array([Vector2(left, top), Vector2(-left, top), Vector2(-left, -top), Vector2(left, -top)])
	var cap := 19.0 if is_ground else 8.0
	top_visual.position.y = top
	top_visual.polygon = PackedVector2Array([Vector2(left, 0), Vector2(-left, 0), Vector2(-left, cap), Vector2(left, cap)])
	body_visual.color = Color("bd6c42") if is_ground else Color("d9864e")
	top_visual.color = Color("54ba59") if is_ground else Color("f1b34c")
